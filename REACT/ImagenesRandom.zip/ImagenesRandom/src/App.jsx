import './App.css'
import ImagenRandom from './components/ImagenRandom'

function App() {
  return (
    <>
      <ImagenRandom></ImagenRandom>
    </>
  )
}

export default App
